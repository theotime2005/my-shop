<script>
import { useRouter } from 'vue-router';
import FlashMessage from "@/components/FlashMessage.vue";

export default {
  components: {
    FlashMessage,
  },
  setup() {
    const router = useRouter();

    const leave = () => {
      const isLeaveIn = true;

      if (isLeaveIn) {
        router.push('/admin/categories');
      } else {
        console.error("Leave failed.");
      }
    };

    return { leave };
  },
  data() {
    return {
      categoryName: ''
    };
  },
  methods: {
    showFlashMessage(message, reload) {
      this.$refs.flashMessage.displayFlash(message, reload);
    },
    async addCategory() {
      try {
        const newCategory = {
          name: this.categoryName
        };

        // remplace l'URL par l'API réelle
        const response = await fetch('http://localhost/api/categories', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${sessionStorage.getItem("user_token")}`
          },
          body: JSON.stringify(newCategory),
        });

        if (response.ok) {
          console.log('Catégorie ajouté avec succès');
          this.showFlashMessage("Category added", '/admin/categories');
        } else {
          console.error('Échec de l\'ajout de la catégorie');
          this.showFlashMessage("Failed to add!");
        }
      } catch (error) {
        console.error('Une erreur s\'est produite', error);
        this.showFlashMessage("Failed to add!");
      }
    },
  },
};
</script>

<template>
  <div class="content">
    <header>
      <div class="leave-container">
        <button class="custom-button" @click="leave">Leave</button>
      </div>
    </header>
      <h2>Add a category</h2>
    <div class="category-add">
      <form @submit.prevent="addCategory">
        <input class="custom-container-name" v-model="categoryName" type="text" placeholder="Category name" id="categoryName" required>

        <flash-message ref="flashMessage"></flash-message>
        <button class="custom-button-add" type="submit">Add</button>
      </form>
    </div>
  </div>
</template>

<style scoped>

.content {
  width: 95%;
  align-items: center;
}

.titre {
  display: flex;
  align-content: center;
}

.custom-button {
  background-color: mediumseagreen;
  color: white;
  border: 1px;
  padding: 10px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  border-radius: 5px;
  transition: background-color 0.3s;
}

.custom-button:hover {
  background-color: darkgreen;
}

.custom-button:active {
  background-color: forestgreen;
}

.custom-button-add {
  background-color: mediumseagreen;
  color: white;
  border: 1px;
  padding: 10px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  border-radius: 5px;
  transition: background-color 0.3s;
  margin-bottom: 10px;
}

.custom-button-add:hover {
  background-color: darkgreen;
}

.custom-button-add:active {
  background-color: forestgreen;
}

.leave-container {
  display: flex;
  align-items: flex-end;
}

header {
  display: flex;
  justify-content: space-between;
  padding: 10px;
  background-color: #181818;
  width: 100%;
  height: 100%;
  align-items: center;
}

.custom-container {
  background-color: dimgray;
  color: white;
  border: 1px;
  padding: 10px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  border-radius: 5px;
  transition: background-color 0.3s;
  margin-bottom: 10px;
}

.custom-container:hover {
  background-color: darkslategrey;
}

.custom-container:active {
  background-color: darkslategrey;
}

.custom-container-name {
  background-color: dimgray;
  color: white;
  border: 1px;
  padding: 10px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  border-radius: 5px;
  transition: background-color 0.3s;
  margin-bottom: 10px;
  margin-top: 20px;
}

.custom-container-name:hover {
  background-color: darkslategrey;
}

.custom-container-name:active {
  background-color: darkslategrey;
}

.product-edit {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: lightgrey;
  width: 300px;
  height: 225px;
  margin: auto;
  border-radius: 5px;
}

.user-add form {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: lightgrey;
  width: 300px;
  height: 225px;
  margin: auto;
  border-radius: 5px;
}
</style>

